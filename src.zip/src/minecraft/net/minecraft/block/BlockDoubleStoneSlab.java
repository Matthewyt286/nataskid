package net.minecraft.block;

public class BlockDoubleStoneSlab extends BlockStoneSlab
{
    private static final String __OBFID = "CL_00002113";

    public boolean isDouble()
    {
        return true;
    }
}
