package net.minecraft.block;

public class BlockDoubleWoodSlab extends BlockWoodSlab
{
    private static final String __OBFID = "CL_00002112";

    public boolean isDouble()
    {
        return true;
    }
}
