package Natasha.ui;

import java.util.Collections;
import java.util.Comparator;

import Natasha.Client;
import Natasha.Mod.Mod;
import Natasha.Mod.ModuleManager;
import Natasha.util.DrawingUtils;
import Natasha.util.RainbowUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;

public class HUD {
	
	public static Minecraft mc = Minecraft.getMinecraft();
	
	public static class ModuleComparator implements Comparator<Mod> {

		public int compare(Mod o1, Mod o2) {
			if (Minecraft.getMinecraft().fontRendererObj
					.getStringWidth(o1.name) > Minecraft.getMinecraft().fontRendererObj.getStringWidth(o2.name)) {
				return -1;
			}
			if (Minecraft.getMinecraft().fontRendererObj
					.getStringWidth(o1.name) < Minecraft.getMinecraft().fontRendererObj.getStringWidth(o2.name)) {
				return 1;
			}

			return 0;
		}

	}
	
	public static void draw() {
		
		ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft(), Minecraft.getMinecraft().displayWidth, Minecraft.getMinecraft().displayHeight);
		FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
		
		Collections.sort(Client.moduleManager.getModules(), new ModuleComparator());
		
		DrawingUtils.drawRoundedRect(5, 5, 81, 25, 0x90000000);
		DrawingUtils.drawScaledString("N", 7, 4, 1.5F, RainbowUtil.rainbowEffect(2 * 2000000000L, 1.0F).getRGB(), true);
		DrawingUtils.drawScaledString("ataskid v" + Client.ver, 13, 4, 1.5F, -1, true);
		DrawingUtils.drawScaledString("FPS:  " + mc.func_175610_ah(), 7, 14, 1.5F, -1, true);
//		DrawingUtils.drawScaledString("X:vgf", 7, 24, 1.5F, -1, true);
		
		//arraylist :D
		int count = 0;

		for (Mod m : Client.INSTANCE.moduleManager.getModules()) {
			if (!m.isToggled())
				continue;

			double offset = count * (fr.FONT_HEIGHT + 6);

			
			
			Gui.drawRect(sr.getScaledWidth() - fr.getStringWidth(m.getName()) - 4, offset, sr.getScaledWidth(), 6 + fr.FONT_HEIGHT + offset, 0x90000000);
			
			Gui.drawRect(sr.getScaledWidth() - 3 - fr.getStringWidth(m.getName()), offset, sr.getScaledWidth() - fr.getStringWidth(m.getName()) - 5, 6 + fr.FONT_HEIGHT + offset, RainbowUtil.rainbowEffect(count * 200000000L, 1.0F).getRGB());
			
			fr.drawString(m.getName(), sr.getScaledWidth() - fr.getStringWidth(m.getName()) - 1, 4 + offset, RainbowUtil.rainbowEffect(count * 200000000L, 1.0F).getRGB());
//			DrawingUtils.drawScaledString(m.getName(), sr.getScaledWidth() - fr.getStringWidth(m.getName()) - 1, (int) (1 + offset), 1.5F, RainbowUtil.rainbowEffect(count * 200000000L, 1.0F).getRGB(), true);
			
			
			count++;
		}
	}

}
