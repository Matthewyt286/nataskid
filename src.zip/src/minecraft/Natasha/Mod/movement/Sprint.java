package Natasha.Mod.movement;

import org.lwjgl.input.Keyboard;

import Natasha.Mod.Category;
import Natasha.Mod.Mod;

public class Sprint extends Mod{
	
	public Sprint() {
		super("Sprint", 0, Category.MOVEMENT);
	}
	
	public void onUpdate() {
		if(this.isToggled())
			mc.thePlayer.setSprinting(true);
	}
	
	public void onDisable() {
		mc.thePlayer.setSprinting(false);
	}

}
