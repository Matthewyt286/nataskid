package Natasha.Mod.movement;

import java.util.ArrayList;

import org.lwjgl.input.Keyboard;

import Natasha.Client;
import Natasha.Mod.Category;
import Natasha.Mod.Mod;
import Natasha.settings.Setting;
import Natasha.util.TimerUtils;
import net.minecraft.block.material.Material;

public class LongJump extends Mod{
	
	
	public TimerUtils timer = new TimerUtils();
	public double startY = 0;
	
	public LongJump() {
		super("LongJump", Keyboard.KEY_L, Category.MOVEMENT);
	}
	
	public void setup() {
		ArrayList<String> options = new ArrayList<String>();
        options.add("VULCAN");
        
        Client.INSTANCE.settingsManager.rSetting(new Setting("LongJump Mode", this, "VULCAN", options));
	}
	
	public void onEnable() {
		if(Client.INSTANCE.settingsManager.getSettingByName("LongJump Mode").getValString().equalsIgnoreCase("VULCAN")) {
			startY = player().posY;
		}
	}
	
	public void onUpdate() {
		if(this.isToggled()) {
			if(Client.INSTANCE.settingsManager.getSettingByName("LongJump Mode").getValString().equalsIgnoreCase("VULCAN")) {

						if (startY > player().posY)
							player().motionY = 0.5;
				
						double oldY = mc.thePlayer.motionY;
						float oldJ = mc.thePlayer.jumpMovementFactor;
						if(this.isToggled()) {
							if((mc.thePlayer.motionY < 0.0d) && (mc.thePlayer.isAirBorne) && (!mc.thePlayer.isInWater()) && (!mc.thePlayer.isOnLadder())) {
								if(!mc.thePlayer.isInsideOfMaterial(Material.lava)) {
									mc.thePlayer.motionY = -.125d;
									mc.thePlayer.jumpMovementFactor *= 1.12337f;
								}
							}
						}else {
							mc.thePlayer.motionY = oldY;
							mc.thePlayer.jumpMovementFactor = oldJ;
						}
			}
		}
	}

}
