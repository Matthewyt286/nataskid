package Natasha.Mod.movement;

import org.lwjgl.input.Keyboard;

import Natasha.Mod.Category;
import Natasha.Mod.Mod;

public class Flight extends Mod{
	
	public Flight() {
		super("Flight", Keyboard.KEY_G, Category.MOVEMENT);
	}
	
	public void onUpdate() {
		if(this.isToggled())
			mc.thePlayer.capabilities.isFlying = true;
	}
	
	public void onDisable() {
		mc.thePlayer.capabilities.isFlying = false;
	}

}
