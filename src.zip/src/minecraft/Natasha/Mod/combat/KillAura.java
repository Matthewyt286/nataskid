package Natasha.Mod.combat;

import net.minecraft.entity.EntityLivingBase;

public class KillAura {
	
	public static boolean blocking = false;
	public static boolean KAT = false;
	public static EntityLivingBase currentTarget;

}
