package Natasha.Mod.client;

import java.util.ArrayList;

import Natasha.Client;
import Natasha.Mod.Category;
import Natasha.Mod.Mod;
import Natasha.Mod.combat.KillAura;
import Natasha.settings.Setting;

public class Animations extends Mod{
	
	public static int aniMode = 0;
	
	public static boolean swingani = false;
	
	public static double itemX = 0;
	public static double itemY = 0;
	public static double itemZ = 0;
	
	public Animations() {
		super("Animations", 0, Category.CLIENT);
	}
	
	public void setup() {
		ArrayList<String> options = new ArrayList<String>();
        options.add("None");
        options.add("Vanilla");
        options.add("1.7");
        options.add("Tap1");
        options.add("Slide Remix");
        options.add("Slide Remix2");
        
        Client.INSTANCE.settingsManager.rSetting(new Setting("Animation", this, "None", options));
        Client.INSTANCE.settingsManager.rSetting(new Setting("Swing Animations", this, false));
        Client.INSTANCE.settingsManager.rSetting(new Setting("NO ANI", this, false));

        Client.INSTANCE.settingsManager.rSetting(new Setting("Always Block", this, false));
        
		Client.INSTANCE.settingsManager.rSetting(new Setting("ItemX", this, itemX, 0, 10, false));
		Client.INSTANCE.settingsManager.rSetting(new Setting("ItemY", this, itemY, 0, 10, false));
		Client.INSTANCE.settingsManager.rSetting(new Setting("ItemZ", this, itemZ, 0, 10, false));
        
	}
	
	public void onEnable() {
		toggle();
	}
	
	public void onUpdate() {
		if(Client.settingsManager.getSettingByName("Swing Animations").getValBoolean()) {
			swingani = true;
		}else {
			swingani = false;
		}
		if(Client.INSTANCE.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("None")) {
			aniMode = 0;
		}
		if(Client.INSTANCE.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("Vanilla")) {
			aniMode = 1;
		}
		if(Client.INSTANCE.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("Tap1")) {
			aniMode = 2;
		}
		if(Client.INSTANCE.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("Slide Remix")) {
			aniMode = 3;
		}
		if(Client.INSTANCE.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("Slide Remix2")) {
			aniMode = 4;
		}
		if(Client.INSTANCE.settingsManager.getSettingByName("Animation").getValString().equalsIgnoreCase("1.7")) {
			aniMode = 5;
		}
		if(Client.INSTANCE.settingsManager.getSettingByName("Always Block").getValBoolean()) {
			KillAura.blocking = true;
		}else {
			if(KillAura.KAT != true && KillAura.currentTarget != null)
				KillAura.blocking = false;
		}
		itemX = Client.settingsManager.getSettingByName("ItemX").getValDouble();
		itemY = Client.settingsManager.getSettingByName("ItemY").getValDouble();
		itemZ = Client.settingsManager.getSettingByName("ItemZ").getValDouble();
	}
	
	

}
