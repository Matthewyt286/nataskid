package Natasha.Mod.render;

import org.lwjgl.input.Keyboard;

import Natasha.Client;
import Natasha.Mod.Category;
import Natasha.Mod.Mod;

public class ClickGui extends Mod{
	
	public ClickGui clickgui;
	
	public ClickGui() {
		super("ClickGUI", Keyboard.KEY_RSHIFT, Category.RENDER);
	}
	
	@Override
    public void onEnable()
    {
    	if(Client.clickGUI == null)
    		Client.clickGUI = new Natasha.clickgui.ClickGui();
    	
    	mc.displayGuiScreen(Client.clickGUI);
    	toggle();
    	super.onEnable();
    }

}
