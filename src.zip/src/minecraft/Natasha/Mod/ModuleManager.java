package Natasha.Mod;

import java.util.ArrayList;
import java.util.List;

import Natasha.Client;
import Natasha.Mod.client.Animations;
import Natasha.Mod.movement.Flight;
import Natasha.Mod.movement.LongJump;
import Natasha.Mod.movement.Scaffold;
import Natasha.Mod.movement.Sprint;
import Natasha.Mod.render.ClickGui;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;

public class ModuleManager {

	private static ArrayList<Mod> mods;

	public ModuleManager() {
		mods = new ArrayList<Mod>();
		
		newMod(new Sprint());
		newMod(new Flight());
		newMod(new Animations());
		newMod(new ClickGui());
		newMod(new LongJump());
		newMod(new Scaffold());
		
	}

	public static List<Mod> getModulesbyCategory(Category c) {
		List<Mod> modules = new ArrayList<Mod>();

		for (Mod m : Client.INSTANCE.moduleManager.getModules()) {
			if (m.category == c)
				modules.add(m);
		}
		return modules;
	}

	public static void newMod(Mod m) {
		mods.add(m);
	}

	public static ArrayList<Mod> getModules() {
		return mods;
	}

	public static void onUpdate() {
		for (Mod m : mods) {
			m.onUpdate();
		}
	}

	public static void onRender() {
		for (Mod m : mods) {
			m.onRender();
		}
	}

	public static void onKey(int k) {
		for (Mod m : mods) {
			if (m.getKey() == k) {
				m.toggle();
			}
		}
	}
	
	public static void addChatMessage(String message) {
		message = "\u00A75" + "Andos Client" + "\2477: " + message;
		
		Minecraft.getMinecraft().thePlayer.addChatMessage(new ChatComponentText(message));
	}

}
