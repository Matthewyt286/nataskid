package Natasha;

import javax.swing.JOptionPane;

import org.lwjgl.opengl.Display;

import Natasha.Mod.ModuleManager;
import Natasha.clickgui.ClickGui;
import Natasha.settings.SettingsManager;

public class Client {
	
	public static Client INSTANCE = new Client();
	public static SettingsManager settingsManager = new SettingsManager();
	public static ModuleManager moduleManager = new ModuleManager();
	public static ClickGui clickGUI;
	
	public static String name = "Nataskid";
	public static double ver = 0.01;
	
	public static void start() {
		Display.setTitle(name + " v" + ver);
	}

}
